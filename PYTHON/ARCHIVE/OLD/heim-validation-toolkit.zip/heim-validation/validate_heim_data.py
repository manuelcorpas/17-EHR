#!/usr/bin/env python3
"""
HEIM-Biobank Data Validation Script
====================================
Comprehensive validation of all JSON data files for logical consistency,
cross-file validation, and detection of anomalies.
"""

import json
import os
from pathlib import Path
from collections import defaultdict

# Color codes for terminal output
RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
RESET = '\033[0m'
BOLD = '\033[1m'

def load_json(filepath):
    """Load JSON file safely."""
    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except Exception as e:
        print(f"{RED}ERROR: Could not load {filepath}: {e}{RESET}")
        return None

def print_header(title):
    print(f"\n{BOLD}{BLUE}{'='*70}")
    print(f" {title}")
    print(f"{'='*70}{RESET}\n")

def print_issue(severity, message):
    if severity == 'CRITICAL':
        print(f"  {RED}🚨 CRITICAL: {message}{RESET}")
    elif severity == 'WARNING':
        print(f"  {YELLOW}⚠️  WARNING: {message}{RESET}")
    elif severity == 'INFO':
        print(f"  {BLUE}ℹ️  INFO: {message}{RESET}")
    elif severity == 'OK':
        print(f"  {GREEN}✓ OK: {message}{RESET}")

def validate_summary(data, all_data):
    """Validate summary.json against other files."""
    print_header("1. SUMMARY.JSON VALIDATION")
    issues = []
    
    # Check overview totals
    overview = data.get('overview', {})
    
    # Cross-check biobank count
    biobanks_data = all_data.get('biobanks', {})
    actual_biobanks = len(biobanks_data.get('biobanks', []))
    reported_biobanks = overview.get('totalBiobanks', 0)
    
    if actual_biobanks != reported_biobanks:
        print_issue('CRITICAL', f"Biobank count mismatch: summary says {reported_biobanks}, biobanks.json has {actual_biobanks}")
        issues.append('biobank_count_mismatch')
    else:
        print_issue('OK', f"Biobank count matches: {reported_biobanks}")
    
    # Cross-check disease count
    diseases_data = all_data.get('diseases', {})
    actual_diseases = len(diseases_data.get('diseases', []))
    reported_diseases = overview.get('totalDiseases', 0)
    
    if actual_diseases != reported_diseases:
        print_issue('CRITICAL', f"Disease count mismatch: summary says {reported_diseases}, diseases.json has {actual_diseases}")
        issues.append('disease_count_mismatch')
    else:
        print_issue('OK', f"Disease count matches: {reported_diseases}")
    
    # Validate gap distribution
    gap_dist = data.get('gapDistribution', {})
    total_gaps = sum(gap_dist.values())
    if total_gaps != reported_diseases:
        print_issue('WARNING', f"Gap distribution total ({total_gaps}) doesn't match disease count ({reported_diseases})")
    
    # Check critical gaps list
    critical_gaps = data.get('criticalGaps', [])
    print(f"\n  Critical gaps reported in summary:")
    for gap in critical_gaps:
        pubs = gap.get('publications', 0)
        name = gap.get('name', 'Unknown')
        dalys = gap.get('dalys', 0)
        if pubs == 0:
            print_issue('WARNING', f"{name}: {pubs} publications, {dalys}M DALYs")
        else:
            print(f"    • {name}: {pubs} publications, {dalys}M DALYs")
    
    return issues

def validate_biobanks(data, all_data):
    """Validate biobanks.json data."""
    print_header("2. BIOBANKS.JSON VALIDATION")
    issues = []
    
    biobanks = data.get('biobanks', [])
    
    # Check for required fields
    required_fields = ['id', 'name', 'country', 'region', 'stats', 'scores']
    
    print(f"  Checking {len(biobanks)} biobanks...\n")
    
    total_pubs_from_biobanks = 0
    biobanks_with_zero_pubs = []
    biobanks_with_high_gaps = []
    
    for bb in biobanks:
        name = bb.get('name', 'Unknown')
        stats = bb.get('stats', {})
        scores = bb.get('scores', {})
        
        pubs = stats.get('totalPublications', 0)
        diseases_covered = stats.get('diseasesCovered', 0)
        critical_gaps = stats.get('criticalGaps', 0)
        eas = scores.get('equityAlignment', 0)
        
        total_pubs_from_biobanks += pubs
        
        # Check for zero publications
        if pubs == 0:
            biobanks_with_zero_pubs.append(name)
        
        # Check for biobanks with many critical gaps
        if critical_gaps >= 3:
            biobanks_with_high_gaps.append((name, critical_gaps, pubs))
        
        # Logical check: if has publications, should cover some diseases
        if pubs > 100 and diseases_covered == 0:
            print_issue('CRITICAL', f"{name}: {pubs} publications but 0 diseases covered")
            issues.append(f'{name}_no_diseases')
        
        # Check for missing fields
        for field in required_fields:
            if field not in bb:
                print_issue('WARNING', f"{name}: missing field '{field}'")
    
    # Report zero publication biobanks
    if biobanks_with_zero_pubs:
        print_issue('WARNING', f"{len(biobanks_with_zero_pubs)} biobanks with 0 publications:")
        for name in biobanks_with_zero_pubs:
            print(f"      • {name}")
    
    # Cross-check total publications
    summary_pubs = all_data.get('summary', {}).get('overview', {}).get('totalPublications', 0)
    print(f"\n  Publication totals:")
    print(f"    • Sum from biobanks: {total_pubs_from_biobanks:,}")
    print(f"    • Summary reports: {summary_pubs:,}")
    
    if total_pubs_from_biobanks != summary_pubs:
        print_issue('WARNING', f"Publication total mismatch: sum={total_pubs_from_biobanks:,}, summary={summary_pubs:,}")
    
    return issues

def validate_diseases(data, all_data):
    """Validate diseases.json - THE MOST CRITICAL CHECK."""
    print_header("3. DISEASES.JSON VALIDATION - CRITICAL")
    issues = []
    
    diseases = data.get('diseases', [])
    
    print(f"  Checking {len(diseases)} diseases...\n")
    
    # Known high-publication diseases that MUST have significant research
    expected_high_pub_diseases = {
        'type2_diabetes': ('Type 2 Diabetes', 1000),  # (name_fragment, min_expected_pubs)
        'diabetes': ('Diabetes', 1000),
        'cardiovascular': ('Cardiovascular', 500),
        'heart': ('Heart Disease', 500),
        'stroke': ('Stroke', 500),
        'cancer': ('Cancer', 500),
        'alzheimer': ('Alzheimer', 300),
        'depression': ('Depression', 300),
        'obesity': ('Obesity', 300),
        'hypertension': ('Hypertension', 300),
    }
    
    zero_pub_diseases = []
    low_pub_diseases = []
    
    print("  Disease Publication Analysis:")
    print("  " + "-"*60)
    
    for d in sorted(diseases, key=lambda x: x.get('research', {}).get('globalPublications', 0)):
        name = d.get('name', 'Unknown')
        category = d.get('category', 'Unknown')
        burden = d.get('burden', {})
        research = d.get('research', {})
        gap = d.get('gap', {})
        
        dalys = burden.get('dalysMillions', 0)
        pubs = research.get('globalPublications', 0)
        biobanks_engaged = research.get('biobanksEngaged', 0)
        gap_score = gap.get('score', 0)
        severity = gap.get('severity', 'Unknown')
        
        # Check for zero publications
        if pubs == 0:
            zero_pub_diseases.append((name, dalys, severity))
            print_issue('CRITICAL', f"{name}: 0 publications, {dalys}M DALYs, severity={severity}")
            issues.append(f'{name}_zero_pubs')
        elif pubs < 50 and dalys > 20:
            low_pub_diseases.append((name, pubs, dalys))
            print_issue('WARNING', f"{name}: only {pubs} pubs for {dalys}M DALYs")
        
        # Check for known high-publication diseases with suspiciously low counts
        name_lower = name.lower()
        for key, (expected_name, min_pubs) in expected_high_pub_diseases.items():
            if key in name_lower and pubs < min_pubs:
                print_issue('CRITICAL', f"{name}: Only {pubs} publications (expected >{min_pubs} for {expected_name})")
                issues.append(f'{name}_suspiciously_low')
    
    # Summary
    print(f"\n  Summary:")
    print(f"    • Diseases with 0 publications: {len(zero_pub_diseases)}")
    print(f"    • Diseases with <50 publications but >20M DALYs: {len(low_pub_diseases)}")
    
    if zero_pub_diseases:
        print(f"\n  {RED}ZERO PUBLICATION DISEASES:{RESET}")
        for name, dalys, severity in zero_pub_diseases:
            print(f"    • {name}: {dalys}M DALYs ({severity})")
    
    return issues

def validate_matrix(data, all_data):
    """Validate matrix.json cross-referencing."""
    print_header("4. MATRIX.JSON VALIDATION")
    issues = []
    
    biobanks = data.get('biobanks', [])
    diseases = data.get('diseases', [])
    matrix = data.get('matrix', {})
    values = matrix.get('values', [])
    
    print(f"  Matrix dimensions: {len(biobanks)} biobanks × {len(diseases)} diseases")
    
    # Check dimensions match
    if len(values) != len(biobanks):
        print_issue('CRITICAL', f"Row count mismatch: {len(values)} rows vs {len(biobanks)} biobanks")
        issues.append('matrix_row_mismatch')
    
    for i, row in enumerate(values):
        if len(row) != len(diseases):
            print_issue('CRITICAL', f"Row {i} has {len(row)} columns, expected {len(diseases)}")
            issues.append(f'matrix_col_mismatch_row_{i}')
    
    # Calculate column sums (total pubs per disease from matrix)
    disease_pubs_from_matrix = defaultdict(int)
    for bi, row in enumerate(values):
        for di, val in enumerate(row):
            disease_pubs_from_matrix[di] += val
    
    # Cross-check with diseases.json
    diseases_data = all_data.get('diseases', {}).get('diseases', [])
    
    print(f"\n  Cross-checking matrix totals vs diseases.json:")
    mismatches = []
    for di, d in enumerate(diseases_data):
        matrix_total = disease_pubs_from_matrix.get(di, 0)
        reported_total = d.get('research', {}).get('globalPublications', 0)
        
        if matrix_total != reported_total:
            mismatches.append((d.get('name'), matrix_total, reported_total))
    
    if mismatches:
        print_issue('WARNING', f"{len(mismatches)} diseases have matrix vs reported mismatches:")
        for name, matrix_val, reported_val in mismatches[:10]:
            print(f"      • {name}: matrix={matrix_val}, reported={reported_val}")
    else:
        print_issue('OK', "All matrix totals match diseases.json")
    
    return issues

def validate_cross_file_consistency(all_data):
    """Check consistency across all files."""
    print_header("5. CROSS-FILE CONSISTENCY CHECK")
    issues = []
    
    # Get biobank IDs from different files
    biobank_ids_main = set(b.get('id') for b in all_data.get('biobanks', {}).get('biobanks', []))
    biobank_ids_matrix = set(b.get('id') for b in all_data.get('matrix', {}).get('biobanks', []))
    biobank_ids_comparison = set(b.get('id') for b in all_data.get('comparison', {}).get('biobanks', []))
    biobank_ids_trends = set(all_data.get('trends', {}).get('byBiobank', {}).keys())
    
    print(f"  Biobank ID counts:")
    print(f"    • biobanks.json: {len(biobank_ids_main)}")
    print(f"    • matrix.json: {len(biobank_ids_matrix)}")
    print(f"    • comparison.json: {len(biobank_ids_comparison)}")
    print(f"    • trends.json: {len(biobank_ids_trends)}")
    
    # Check for missing biobanks in matrix
    missing_in_matrix = biobank_ids_main - biobank_ids_matrix
    if missing_in_matrix:
        print_issue('WARNING', f"Biobanks in main but not in matrix: {missing_in_matrix}")
    
    # Get disease IDs
    disease_ids_main = set(d.get('id') for d in all_data.get('diseases', {}).get('diseases', []))
    disease_ids_matrix = set(d.get('id') for d in all_data.get('matrix', {}).get('diseases', []))
    
    print(f"\n  Disease ID counts:")
    print(f"    • diseases.json: {len(disease_ids_main)}")
    print(f"    • matrix.json: {len(disease_ids_matrix)}")
    
    missing_diseases = disease_ids_main - disease_ids_matrix
    if missing_diseases:
        print_issue('WARNING', f"Diseases in main but not in matrix: {missing_diseases}")
    
    return issues

def validate_equity(data, all_data):
    """Validate equity.json data."""
    print_header("6. EQUITY.JSON VALIDATION")
    issues = []
    
    summary = data.get('summary', {})
    hic = summary.get('hic', {})
    lmic = summary.get('lmic', {})
    
    hic_biobanks = hic.get('biobanks', 0)
    lmic_biobanks = lmic.get('biobanks', 0)
    total_biobanks = hic_biobanks + lmic_biobanks
    
    hic_pubs = hic.get('publications', 0)
    lmic_pubs = lmic.get('publications', 0)
    total_pubs = hic_pubs + lmic_pubs
    
    print(f"  HIC: {hic_biobanks} biobanks, {hic_pubs:,} publications")
    print(f"  LMIC: {lmic_biobanks} biobanks, {lmic_pubs:,} publications")
    print(f"  Total: {total_biobanks} biobanks, {total_pubs:,} publications")
    
    # Cross-check with summary
    summary_data = all_data.get('summary', {}).get('overview', {})
    if total_biobanks != summary_data.get('totalBiobanks', 0):
        print_issue('WARNING', f"Biobank count mismatch: equity={total_biobanks}, summary={summary_data.get('totalBiobanks')}")
    
    if total_pubs != summary_data.get('totalPublications', 0):
        print_issue('WARNING', f"Publication count mismatch: equity={total_pubs:,}, summary={summary_data.get('totalPublications'):,}")
    
    # Check equity ratio calculation
    reported_ratio = data.get('equityRatio', 0)
    if lmic_pubs > 0:
        calculated_ratio = hic_pubs / lmic_pubs
        if abs(calculated_ratio - reported_ratio) > 0.1:
            print_issue('WARNING', f"Equity ratio mismatch: reported={reported_ratio:.2f}, calculated={calculated_ratio:.2f}")
    
    return issues

def generate_report(all_issues):
    """Generate final validation report."""
    print_header("VALIDATION REPORT SUMMARY")
    
    total_issues = sum(len(issues) for issues in all_issues.values())
    critical_count = sum(1 for issues in all_issues.values() for i in issues if 'zero_pubs' in i or 'mismatch' in i)
    
    print(f"  Total issues found: {total_issues}")
    print(f"  Critical issues: {critical_count}")
    
    if total_issues == 0:
        print(f"\n  {GREEN}✓ All validations passed!{RESET}")
    else:
        print(f"\n  {RED}Issues by category:{RESET}")
        for category, issues in all_issues.items():
            if issues:
                print(f"    • {category}: {len(issues)} issues")
    
    print(f"\n  {BOLD}RECOMMENDATIONS:{RESET}")
    
    if any('zero_pubs' in str(i) for issues in all_issues.values() for i in issues):
        print(f"  {RED}1. CRITICAL: Review disease publication mapping - major diseases show 0 publications{RESET}")
        print(f"     This suggests the MeSH-to-disease mapping may be failing")
    
    if any('mismatch' in str(i) for issues in all_issues.values() for i in issues):
        print(f"  {YELLOW}2. WARNING: Cross-file totals don't match - regenerate from single source{RESET}")

def main():
    """Main validation routine."""
    print(f"\n{BOLD}HEIM-Biobank Data Validation Script{RESET}")
    print(f"{'='*70}\n")
    
    # Load all data files
    data_dir = Path('/mnt/user-data/uploads')
    
    files = ['summary', 'biobanks', 'diseases', 'matrix', 'trends', 'themes', 'comparison', 'equity']
    all_data = {}
    
    print("Loading data files...")
    for f in files:
        filepath = data_dir / f"{f}.json"
        data = load_json(filepath)
        if data:
            all_data[f] = data
            print(f"  ✓ Loaded {f}.json")
        else:
            print(f"  ✗ Failed to load {f}.json")
    
    all_issues = {}
    
    # Run validations
    all_issues['summary'] = validate_summary(all_data.get('summary', {}), all_data)
    all_issues['biobanks'] = validate_biobanks(all_data.get('biobanks', {}), all_data)
    all_issues['diseases'] = validate_diseases(all_data.get('diseases', {}), all_data)
    all_issues['matrix'] = validate_matrix(all_data.get('matrix', {}), all_data)
    all_issues['cross_file'] = validate_cross_file_consistency(all_data)
    all_issues['equity'] = validate_equity(all_data.get('equity', {}), all_data)
    
    # Generate report
    generate_report(all_issues)

if __name__ == "__main__":
    main()
